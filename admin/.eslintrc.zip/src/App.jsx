import React from "react";
import Admin from "./Pages/Admin";

const App = () => {
  return (
    <div>
      <Admin />
    </div>
  );
};

export default App;
